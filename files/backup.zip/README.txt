Sample archive for the wb-starter file card demos.
